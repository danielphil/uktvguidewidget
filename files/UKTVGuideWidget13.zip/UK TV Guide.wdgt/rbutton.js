// UK TV Guide Widget
// © 2005-2010 Daniel Phillips
// uktvwidget@googlemail.com

function rbuttonHilite(event) {
var buttonBack = document.getElementById("refreshButtonBackground");
buttonBack.style.display="block";
}

function rbuttonNoHilite(event) {
var buttonBack = document.getElementById("refreshButtonBackground");
buttonBack.style.display="none";
}